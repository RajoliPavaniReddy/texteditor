// src/App.tsx
import React from 'react';
import './App.css';
import FontSelector from './components/FontSelector';

const App: React.FC = () => {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Text Editor</h1>
      </header>
      <main>
        <FontSelector />
      </main>
    </div>
  );
};

export default App;
