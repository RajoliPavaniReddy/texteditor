// src/webfontloader.d.ts
declare module 'webfontloader' {
    interface WebFontConfig {
      custom?: {
        families: string[];
        urls: string[];
      };
      timeout?: number;
      active?: () => void;
      inactive?: () => void;
      fontloading?: (familyName: string, fvd: string) => void;
      fontactive?: (familyName: string, fvd: string) => void;
      fontinactive?: (familyName: string, fvd: string) => void;
    }
  
    function load(config: WebFontConfig): void;
  }
  