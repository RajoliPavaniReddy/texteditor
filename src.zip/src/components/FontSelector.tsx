// src/components/FontSelector.tsx
import React, { useEffect, useState } from 'react';
import WebFont from 'webfontloader';

interface Fonts {
  [key: string]: {
    [weight: string]: string;
  };
}

const FontSelector: React.FC = () => {
  const [fonts, setFonts] = useState<Fonts>({});
  const [selectedFont, setSelectedFont] = useState('');
  const [selectedWeight, setSelectedWeight] = useState('');
  const [isItalic, setIsItalic] = useState(false);
  const [text, setText] = useState('');

  useEffect(() => {
    fetch('/fonts.json')
      .then(response => response.json())
      .then(data => setFonts(data));
  }, []);

  useEffect(() => {
    if (selectedFont) {
      const weights = Object.keys(fonts[selectedFont]);
      setSelectedWeight(weights[0]);
    }
  }, [selectedFont, fonts]);

  useEffect(() => {
    if (selectedFont && selectedWeight) {
      const italicSuffix = isItalic ? 'italic' : '';
      const fontUrl = fonts[selectedFont][`${selectedWeight}${italicSuffix}`];
      WebFont.load({
        custom: {
          families: [`${selectedFont}:${selectedWeight}${italicSuffix}`],
          urls: [fontUrl],
        },
      });
    }
  }, [selectedFont, selectedWeight, isItalic, fonts]);

  useEffect(() => {
    const savedState = localStorage.getItem('editorState');
    if (savedState) {
      const { font, weight, italic, text } = JSON.parse(savedState);
      setSelectedFont(font);
      setSelectedWeight(weight);
      setIsItalic(italic);
      setText(text);
    }
  }, []);

  const handleSaveState = () => {
    localStorage.setItem(
      'editorState',
      JSON.stringify({
        font: selectedFont,
        weight: selectedWeight,
        italic: isItalic,
        text,
      })
    );
  };

  return (
    <div className="editor">
      <select
        value={selectedFont}
        onChange={(e) => setSelectedFont(e.target.value)}
      >
        <option value="">Select Font</option>
        {Object.keys(fonts).map((font) => (
          <option key={font} value={font}>
            {font}
          </option>
        ))}
      </select>

      {selectedFont && (
        <select
          value={selectedWeight}
          onChange={(e) => setSelectedWeight(e.target.value)}
        >
          {Object.keys(fonts[selectedFont])
            .filter((weight) => !weight.includes('italic'))
            .map((weight) => (
              <option key={weight} value={weight}>
                {weight}
              </option>
            ))}
        </select>
      )}

      {selectedFont && selectedWeight && (
        <label>
          <input
            type="checkbox"
            checked={isItalic}
            onChange={(e) => setIsItalic(e.target.checked)}
          />
          Italic
        </label>
      )}

      <textarea
        style={{
          fontFamily: selectedFont,
          fontWeight: selectedWeight,
          fontStyle: isItalic ? 'italic' : 'normal',
        }}
        value={text}
        onChange={(e) => setText(e.target.value)}
        onBlur={handleSaveState}
      />
    </div>
  );
};

export default FontSelector;
